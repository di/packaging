=============
 about mudpy
=============

:Copyright: (c) 2004-2016 Jeremy Stanley <fungi@yuggoth.org>. Permission
            to use, copy, modify, and distribute this software is
            granted under terms provided in the LICENSE file distributed
            with this software.

The mudpy project aims to create a simple, generic, cross-platform,
freely-redistributable MUD core engine which can be easily understood
and extended. It is written in pure Python (currently compatible with
3.3 and later versions) and has only pure Python dependencies. All
configuration and data are stored in consistently-formatted plain text
(YAML) files for ease of administration. The core engine is
unicode-clean internally and supports UTF-8 encoding for input and
output of extended text characters.

The mudpy program and sample content are released under a free and open
license, and any bug reports, criticisms, ideas, patches, content
submissions or other offers of collaboration are wholeheartedly welcome.

Please review the other documentation files distributed with this
software, or visit http://mudpy.org/res/src/mudpy/doc/ for additional
information.
