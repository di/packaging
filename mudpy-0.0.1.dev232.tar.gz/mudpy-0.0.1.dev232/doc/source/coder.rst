=============
 coder guide
=============

:Copyright: (c) 2004-2017 Jeremy Stanley <fungi@yuggoth.org>. Permission
            to use, copy, modify, and distribute this software is
            granted under terms provided in the LICENSE file distributed
            with this software.

This guide attempts to embody a rudimentary set of rules for developer
submissions of source code and documentation targeted for inclusion
within the mudpy project, as well as pointers to useful resources for
those attempting to obtain a greater understanding of the software.

.. sectnum:: :prefix: 1.
.. contents:: :local:

--------
 source
--------

As with any project, the mudpy source code could always be better
documented, and contributions to that end are heartily welcomed.

version control system
----------------------

Git_ is used for version control on the project, and the archive can be
cloned anonymously from http://mudpy.org/git/mudpy if desired. For now,
detailed commits can be E-mailed to fungi@yuggoth.org, but there will
most likely be a developer mailing list for more open presentation and
discussion of patches soon.

A Gitweb_ interface is available, to make the change history easier to
browse. This is found at http://mudpy.org/gitweb/mudpy/ and should be
fairly self-explanatory.

A ChangeLog file is generated automatically from repository commit
logs, and is included automatically in all sdist_ tarballs. It can
be regenerated easily by running `tox -e venv python setup.py sdist`
from the top level directory of the Git repository in a working
`developer environment`_.

.. _Git: http://git-scm.com/
.. _Gitweb: http://git.wiki.kernel.org/index.php/Gitweb
.. _sdist: https://packaging.python.org/glossary
           /#term-source-distribution-or-sdist

developer environment
---------------------

Basic developer requirements are a POSIX Unix derivative (such as
Linux), a modern Python 3 interpreter (any of the minor revisions
mentioned in the ``metadata.classifier`` section of setup.cfg_) and
a recent release of the tox_ utility (at least the
``tox.minversion`` mentioned in tox.ini_).

.. _setup.cfg: http://mudpy.org/gitweb?p=mudpy.git;a=blob;f=setup.cfg
.. _tox.ini: http://mudpy.org/gitweb?p=mudpy.git;a=blob;f=tox.ini

application program interface
-----------------------------

API documentation is maintained within docstrings in the mudpy source
code.

regression testing
------------------

All new commits are tested using a selftest script in the
``mudpy/tests`` directory of the source archive, to help ensure the
software is continually usable. Any new features should be
accompanied by suitable regression tests so that their functionality
can be maintained properly through future releases. The selftest can
be invoked with ``tox -e selftest`` after starting the daemon with
the test configuration provided in the ``mudpy/tests/fixtures``
directory.

-------
 style
-------

This project follows Guido van Rossum and Barry Warsaw's `Style Guide`_
for Python Code (a.k.a. "PEP-8"). When in need of sample code or other
examples, any common source code file or text document file distributed
as part of mudpy should serve as a suitable reference. Testing of all
new patches with the flake8_ utility should be performed with ``tox
-e flake8`` to ensure adherence to preferred style conventions.

.. _Style Guide: http://www.python.org/dev/peps/pep-0008/
.. _flake8: https://pypi.python.org/pypi/flake8
