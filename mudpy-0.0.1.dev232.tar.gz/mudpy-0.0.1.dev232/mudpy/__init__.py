"""Core modules package for the mudpy engine."""

# Copyright (c) 2004-2017 Jeremy Stanley <fungi@yuggoth.org>. Permission
# to use, copy, modify, and distribute this software is granted under
# terms provided in the LICENSE file distributed with this software.

import sys

import mudpy  # noqa (referenced via exec of string literal below)

if sys.version_info >= (3, 4):
    import importlib  # noqa (referenced via exec of string literal below)
else:
    # Python 3.3 lacks importlib.reload()
    import imp as importlib  # noqa (referenced via exec of string literal)


def load():
    """Import/reload some modules (be careful, as this can result in loops)."""

    # pick up the modules list from this package
    global modules

    # iterate over the list of modules provided
    for module in modules:

        # attempt to reload the module, assuming it was probably imported
        # earlier
        try:
            exec("importlib.reload(%s)" % module)

        # must not have been, so import it now
        except NameError:
            exec("import mudpy.%s" % module)


# load the modules contained in this package
modules = ["data", "misc", "password", "telnet"]
load()
