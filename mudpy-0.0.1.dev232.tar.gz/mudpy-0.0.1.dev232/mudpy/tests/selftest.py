# Copyright (c) 2004-2017 Jeremy Stanley <fungi@yuggoth.org>. Permission
# to use, copy, modify, and distribute this software is granted under
# terms provided in the LICENSE file distributed with this software.

import os
import re
import sys
import telnetlib
import time

test_account0_setup = (
    (0, "Identify yourself:", "luser0"),
    (0, "Enter your choice:", "n"),
    (0, 'Enter a new password for "luser0":', "Test123"),
    (0, "Enter the same new password again:", "Test123"),
    (0, r"What would you like to do\?", "c"),
    (0, "Pick a birth gender for your new avatar:", "f"),
    (0, "Choose a name for her:", "1"),
    (0, "What would you like to do?", "a"),
    (0, "Whom would you like to awaken?", ""),
)

test_account1_setup = (
    (1, "Identify yourself:", "luser1"),
    (1, "Enter your choice:", "n"),
    (1, 'Enter a new password for "luser1":', "Test456"),
    (1, "Enter the same new password again:", "Test456"),
    (1, r"What would you like to do\?", "c"),
    (1, "Pick a birth gender for your new avatar:", "m"),
    (1, "Choose a name for him:", "1"),
    (1, "What would you like to do?", "a"),
    (1, "Whom would you like to awaken?", ""),
)

test_actor_appears = (
    (0, r"You suddenly realize that .* is here\.", ""),
)

test_explicit_punctuation = (
    (0, "> ", "say Hello there!"),
    (0, r'You exclaim, "Hello there\!"', ""),
    (1, r'exclaims, "Hello there\!"', "say And you are?"),
    (1, r'You ask, "And you are\?"', ""),
    (0, r'asks, "And you are\?"', "say I'm me, of course."),
    (0, r'''You say, "I'm me, of course\."''', ""),
    (1, r'''says, "I'm me, of course\."''', "say I wouldn't be so sure..."),
    (1, r'''You muse, "I wouldn't be so sure\.\.\."''', ""),
    (0, r'''muses, "I wouldn't be so sure\.\.\."''', "say You mean,"),
    (0, 'You begin, "You mean,"', ""),
    (1, 'begins, "You mean,"', "say I know-"),
    (1, 'You begin, "I know-"', ""),
    (0, 'begins, "I know-"', "say Don't interrupt:"),
    (0, r'''You begin, "Don't interrupt:"''', ""),
    (1, r'''begins, "Don't interrupt:"''', "say I wasn't interrupting;"),
    (1, r'''You begin, "I wasn't interrupting;"''', ""),
    (0, r'''begins, "I wasn't interrupting;"''', ""),
)

test_implicit_punctuation = (
    (0, '> ', "say Whatever"),
    (0, r'You say, "Whatever\."', ""),
    (1, r'says, "Whatever\."', ""),
)

test_typo_replacement = (
    (1, '> ', "say That's what i think."),
    (1, r'''You say, "That's what I think\."''', ""),
    (0, r'''says, "That's what I think\."''', "say You know what i'd like."),
    (0, r'''You say, "You know what I'd like\."''', ""),
    (1, r'''says, "You know what I'd like\."''', "say Then i'll tell you."),
    (1, r'''You say, "Then I'll tell you\."''', ""),
    (0, r'''says, "Then I'll tell you\."''', "say Now i'm ready."),
    (0, r'''You say, "Now I'm ready\."''', ""),
    (1, r'''says, "Now I'm ready\."''', "say That's teh idea."),
    (1, r'''You say, "That's the idea\."''', ""),
    (0, r'''says, "That's the idea\."''', "say It's what theyre saying."),
    (0, r'''You say, "It's what they're saying\."''', ""),
    (1, r'''says, "It's what they're saying\."''', "say Well, youre right."),
    (1, r'''You say, "Well, you're right\."''', ""),
    (0, r'''says, "Well, you're right\."''', ""),
)

test_sentence_capitalization = (
    (0, "> ", "say this sentence should start with a capital T."),
    (0, 'You say, "This sentence', ""),
    (1, 'says, "This sentence', ""),
)

test_chat_mode = (
    (1, '> ', "chat"),
    (1, r'(?s)Entering chat mode .*> \(chat\) ', "Feeling chatty."),
    (1, r'You say, "Feeling chatty\."', "!chat"),
    (0, r'says, "Feeling chatty\."', ""),
    (1, '> ', "say Now less chatty."),
    (1, r'You say, "Now less chatty\."', ""),
    (0, r'says, "Now less chatty\."', ""),
)

test_movement = (
    (0, "> ", "move north"),
    (0, r"You exit to the north\.", ""),
    (1, r"exits to the north\.", "move north"),
    (0, r"arrives from the south\.", "move south"),
    (0, r"You exit to the south\.", ""),
    (1, r"exits to the south\.", "move south"),
    (0, r"arrives from the north\.", "move east"),
    (0, r"You exit to the east\.", ""),
    (1, r"exits to the east\.", "move east"),
    (0, r"arrives from the west\.", "move west"),
    (0, r"You exit to the west\.", ""),
    (1, r"exits to the west\.", "move west"),
    (0, r"arrives from the east\.", "move up"),
    (0, r"You exit upward\.", ""),
    (1, r"exits upward\.", "move up"),
    (0, r"arrives from below\.", "move down"),
    (0, r"You exit downward\.", ""),
    (1, r"exits downward\.", "move down"),
    (0, r"arrives from above\.", ""),
)

test_actor_disappears = (
    (1, "> ", "quit"),
    (0, r"You suddenly wonder where .* went\.", ""),
)

test_account1_teardown = (
    (1, "What would you like to do?", "d"),
    (1, "Whom would you like to delete?", ""),
    (1, "What would you like to do?", "p"),
    (1, "permanently delete your account?", "y"),
    (1, "Disconnecting...", ""),
)

test_admin_setup = (
    (2, "Identify yourself:", "admin"),
    (2, "Enter your choice:", "n"),
    (2, 'Enter a new password for "admin":', "Test789"),
    (2, "Enter the same new password again:", "Test789"),
    (2, r"What would you like to do\?", "c"),
    (2, "Pick a birth gender for your new avatar:", "m"),
    (2, "Choose a name for him:", "1"),
    (2, "What would you like to do?", "a"),
    (2, "Whom would you like to awaken?", ""),
)

test_admin_restriction = (
    (0, "> ", "help halt"),
    (0, r"That is not an available command\.", "halt"),
    (0, '(not sure what "halt" means|Arglebargle, glop-glyf)', ""),
)

test_admin_help = (
    (2, "> ", "help"),
    (2, r"halt.*Shut down the world\.", "help halt"),
    (2, "This will save all active accounts", ""),
)

test_reload = (
    (2, "> ", "reload"),
    (2, r"Reloading all code modules, configs and data\."
        r".* User admin reloaded the world\.", ""),
)

test_set_facet = (
    (2, "> ", "set actor.avatar_admin_0 gender female"),
    (2, r'You have successfully \(re\)set the "gender" facet of element', ""),
)

test_set_refused = (
    (2, "> ", "set mudpy.limit password_tries 10"),
    (2, r'The "mudpy\.limit" element is kept in read-only file', ""),
)

test_show_files = (
    (2, "> ", "show files"),
    (2, r'These are the current files containing the universe:.*'
        r'  \x1b\[31m\(rw\) \x1b\[32m/.*/account.yaml\x1b\[0m'
        r' \x1b\[33m\[private\]\x1b\[0m.*> ', ""),
)

test_show_file = (
    (2, "> ", "show file %s" %
        os.path.join(os.getcwd(), "data/internal.yaml")),
    (2, r'These are the nodes in the.*file:.*internal\.counters.*> ', ""),
)

test_show_groups = (
    (2, "> ", "show groups"),
    (2, r'These are the element groups:.*'
        r'  \x1b\[32maccount\x1b\[0m.*> ', ""),
)

test_show_group = (
    (2, "> ", "show group account"),
    (2, r'These are the elements in the "account" group:.*'
        r'  \x1b\[32maccount\.admin\x1b\[0m.*> ', ""),
)

test_show_element = (
    (2, "> ", "show element mudpy.limit"),
    (2, r'These are the properties of the "mudpy\.limit" element.*'
        r'  \x1b\[32mpassword_tries: \x1b\[31m3.*> ',
     "show element actor.avatar_admin_0"),
    (2, r'These are the properties of the "actor.avatar_admin_0" element.*'
        r'  \x1b\[32mgender: \x1b\[31mfemale.*> ', ""),
)

test_show_log = (
    (2, "> ", "show log"),
    (2, r"There are [0-9]+ log lines in memory and [0-9]+ at or above level "
        r"[0-9]+\. The matching lines\r\nfrom [0-9]+ to [0-9]+ are:", ""),
)

test_custom_loglevel = (
    (2, "> ", "set account.admin loglevel 2"),
    (2, "You have successfully .*> ", "show log"),
    (2, r"There are [0-9]+ log lines in memory and [0-9]+ at or above level "
        r"[0-9]+\. The matching lines\r\nfrom [0-9]+ to [0-9]+ are:", ""),
)

test_invalid_loglevel = (
    (2, "> ", "set account.admin loglevel two"),
    (2, r'''Value "two" of type "<class 'str'>" cannot be coerced .*> ''', ""),
)

test_log_no_errors = (
    (2, "> ", "show log 7"),
    (2, r"None of the [0-9]+ lines in memory matches your request\.", ""),
)

dialogue = (
    (test_account0_setup, "first account setup"),
    (test_account1_setup, "second account setup"),
    (test_actor_appears, "actor spontaneous appearance"),
    (test_explicit_punctuation, " explicit punctuation"),
    (test_implicit_punctuation, "implicit punctuation"),
    (test_typo_replacement, "typo replacement"),
    (test_sentence_capitalization, "sentence capitalization"),
    (test_chat_mode, "chat mode"),
    (test_movement, "movement"),
    (test_actor_disappears, "actor spontaneous disappearance"),
    (test_account1_teardown, "second account teardown"),
    (test_admin_setup, "admin account setup"),
    (test_admin_restriction, "restricted admin commands"),
    (test_admin_help, "admin help"),
    (test_reload, "reload"),
    (test_set_facet, "set facet"),
    (test_set_refused, "refuse altering read-only element"),
    (test_show_files, "show a list of loaded files"),
    (test_show_file, "show nodes from a specific file"),
    (test_show_groups, "show groups"),
    (test_show_group, "show group"),
    (test_show_element, "show element"),
    (test_show_log, "show log"),
    (test_custom_loglevel, "custom loglevel"),
    (test_invalid_loglevel, "invalid loglevel"),
    (test_log_no_errors, "no errors logged"),
)


def main():
    captures = ["", "", ""]
    lusers = [telnetlib.Telnet(), telnetlib.Telnet(), telnetlib.Telnet()]
    success = True
    start = time.time()
    for luser in lusers:
        luser.open("::1", 4000)
    for test, description in dialogue:
        print("\nTesting %s..." % description)
        test_start = time.time()
        for conversant, question, answer in test:
            print("luser%s waiting for: %s" % (conversant, question))
            try:
                index, match, received = lusers[conversant].expect(
                    [re.compile(question.encode("utf-8"), flags=re.DOTALL)], 5)
                captures[conversant] += received.decode("utf-8")
            except ConnectionResetError:
                print("ERROR: Unable to connect to server.")
                success = False
                break
            except EOFError:
                print("ERROR: luser%s premature disconnection expecting:\n\n"
                      "%s\n\n"
                      "Check the end of capture_%s.log for received data."
                      % (conversant, question, conversant))
                success = False
                break
            try:
                captures[conversant] += lusers[
                    conversant].read_very_eager().decode("utf-8")
            except Exception:
                pass
            if index is not 0:
                print("ERROR: luser%s did not receive expected string:\n\n"
                      "%s\n\n"
                      "Check the end of capture_%s.log for received data."
                      % (conversant, question, conversant))
                success = False
                break
            print("luser%s sending: %s" % (conversant, answer))
            lusers[conversant].write(("%s\r\n" % answer).encode("utf-8"))
            captures[conversant] += "%s\r\n" % answer
        if not success:
            break
        print("Completed in %.3f seconds." % (time.time() - test_start))
    duration = time.time() - start
    print("")
    for conversant in range(len(captures)):
        try:
            captures[conversant] += lusers[
                conversant].read_very_eager().decode("utf-8")
        except Exception:
            pass
        lusers[conversant].close()
        logfile = "capture_%s.log" % conversant
        print("Recording session %s as %s." % (conversant, logfile))
        log = open(logfile, "w")
        log.write(captures[conversant])
        log.close()
    print("\nRan %s tests in %.3f seconds." % (len(dialogue), duration))
    if success:
        print("SUCCESS")
    else:
        print("FAILURE")
        sys.exit(1)


if __name__ == '__main__':
    sys.exit(main())
