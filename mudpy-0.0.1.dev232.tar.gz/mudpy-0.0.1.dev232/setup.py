# Copyright (c) 2016 Jeremy Stanley <fungi@yuggoth.org>. Permission
# to use, copy, modify, and distribute this software is granted under
# terms provided in the LICENSE file distributed with this software.

import setuptools

setuptools.setup(setup_requires=['pbr>=2.0'], pbr=True)
